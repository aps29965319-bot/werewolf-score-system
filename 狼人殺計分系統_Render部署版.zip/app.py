
from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def home():
    sample=[
        {'name':'玩家A','score':30,'wins':10,'games':15,'mvp':2},
        {'name':'玩家B','score':25,'wins':8,'games':14,'mvp':1}
    ]
    return render_template('index.html', players=sample)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
